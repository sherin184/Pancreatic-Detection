@echo off
cd /d "%~dp0\app\frontend"
call ..\..\.venv\Scripts\activate
npm install
npm run dev -- --host 0.0.0.0 --port 5173
