@echo off
cd /d "%~dp0"
start "Backend" cmd /k "call .venv\Scripts\activate && python -m uvicorn app.backend.main:app --host 0.0.0.0 --port 8003"
start "Frontend" cmd /k "cd app\frontend && call ..\..\.venv\Scripts\activate && npm install && npm run dev -- --host 0.0.0.0 --port 5173"
